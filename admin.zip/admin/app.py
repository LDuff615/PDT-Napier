from flask import Flask, render_template, request, redirect, url_for, flash
from flask_mysqldb import MySQL



app = Flask(__name__)
app.secret_key = 'many random bytes'
#configs to the server
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'flaskapp'

mysql = MySQL(app)

#users cms
#main display of data from database
@app.route('/index')
def Index():
    cur = mysql.connection.cursor()
    cur.execute("SELECT  * FROM users")
    data = cur.fetchall()
    cur.close()




    return render_template('index2.html', users=data )


#input users data into database
@app.route('/insert', methods = ['POST'])
def insert():

     if request.method == "POST":
        flash("Data Inserted Successfully")
        username = request.form['username']
        password = request.form['password']
        types = request.form['type']
        score = request.form['score']
        cur = mysql.connection.cursor()
        cur.execute("INSERT INTO users (username, password, type,score) VALUES (%s, %s, %s, %s)", (username, password, types,score))
        mysql.connection.commit()
        return redirect(url_for('Index'))



#delete data from database
@app.route('/delete/<string:id_data>', methods = ['GET'])
def delete(id_data):
    flash("Record Has Been Deleted Successfully")
    cur = mysql.connection.cursor()
    cur.execute("DELETE FROM users WHERE userID=%s", (id_data,))
    mysql.connection.commit()
    return redirect(url_for('Index'))

#edit data from database
@app.route('/update',methods=['POST','GET'])
def update():

    if request.method == 'POST':
        id_data = request.form['userID']
        username = request.form['username']
        password = request.form['password']
        types = request.form['type']
        score = request.form['score']
        cur = mysql.connection.cursor()
        cur.execute("""
               UPDATE users
               SET username=%s, password=%s, type=%s, score=%s
               WHERE userID=%s
            """, (username, password, types, score, id_data))
        flash("Data Updated Successfully")
        mysql.connection.commit()
        return redirect(url_for('Index'))
#end of users table cms

#response cms
#main display of data from database
@app.route('/test')
def test():
    cur = mysql.connection.cursor()
    cur.execute("SELECT  * FROM response")
    data = cur.fetchall()
    cur.close()




    return render_template('test.html', response=data )


#input users data into database
@app.route('/insert1', methods = ['POST'])
def insert1():

    if request.method == "POST":
        flash("Data Inserted Successfully")
        responseDescription = request.form['responseDescription']
        questionID = request.form['questionID']
        correctAnswer = request.form['correctAnswer']
        cur = mysql.connection.cursor()
        cur.execute("INSERT INTO response (responseDescription, questionID, correctAnswer) VALUES ( %s, %s, %s)", (responseDescription, questionID, correctAnswer))
        mysql.connection.commit()
        return redirect(url_for('test'))



#delete data from database
@app.route('/delete1/<string:id_data>', methods = ['GET'])
def delete1(id_data):
    flash("Record Has Been Deleted Successfully")
    cur = mysql.connection.cursor()
    cur.execute("DELETE FROM response WHERE responseID=%s", (id_data,))
    mysql.connection.commit()
    return redirect(url_for('test'))

#edit data from database
@app.route('/update1',methods=['POST','GET'])
def update1():

    if request.method == 'POST':
        id_data = request.form['responseID']
        responseDescription = request.form['responseDescription']
        questionID = request.form['questionID']
        correctAnswer = request.form['correctAnswer']
        cur = mysql.connection.cursor()
        cur.execute("""
               UPDATE response
               SET responseDescription=%s, questionID=%s, correctAnswer=%s
               WHERE responseID=%s
            """, (responseDescription, questionID, correctAnswer, id_data))
        flash("Data Updated Successfully")
        mysql.connection.commit()
        return redirect(url_for('test'))
#end of response table cms


#questions cms
#main display of data from database
@app.route('/questions')
def questions():
    cur = mysql.connection.cursor()
    cur.execute("SELECT  * FROM question")
    data = cur.fetchall()
    cur.close()




    return render_template('questions.html', question=data )


#input users data into database
@app.route('/insert2', methods = ['POST'])
def insert2():

    if request.method == "POST":
        flash("Data Inserted Successfully")
        questionDescription = request.form['questionDescription']
        cur = mysql.connection.cursor()
        cur.execute("INSERT INTO question (questionDescription) VALUES (%s)", (questionDescription))
        mysql.connection.commit()
        return redirect(url_for('questions'))



#delete data from database however you need to delete all repospe link to questionID first
@app.route('/delete2/<string:id_data>', methods = ['GET'])
def delete2(id_data):
    flash("Record Has Been Deleted Successfully")
    cur = mysql.connection.cursor()
    cur.execute("DELETE FROM question WHERE questionID=%s", (id_data))
    mysql.connection.commit()
    return redirect(url_for('questions'))

#edit data from database
@app.route('/update2',methods=['POST','GET'])
def update2():

    if request.method == 'POST':
        id_data = request.form['questionID']
        questionDescription = request.form['questionDescription']
        cur = mysql.connection.cursor()
        cur.execute("""
               UPDATE question
               SET questionDescription=%s
               WHERE questionID=%s
            """, (questionDescription, id_data))
        flash("Data Updated Successfully")
        mysql.connection.commit()
        return redirect(url_for('questions'))
#end of questions table cms


#reference cms
#main display of data from database
@app.route('/')
def feedback():
    cur = mysql.connection.cursor()
    cur.execute("SELECT  * FROM reference")
    data = cur.fetchall()
    cur.close()




    return render_template('feedback.html', reference=data )


#input users data into database
@app.route('/insert3', methods = ['POST'])
def insert3():

    if request.method == "POST":
        flash("Data Inserted Successfully")
        referenceLink = request.form['referenceLink']
        feedback = request.form['feedback']
        responseID = request.form['responseID']
        cur = mysql.connection.cursor()
        cur.execute("INSERT INTO reference (referenceLink, feedback, responseID) VALUES ( %s, %s, %s)", (referenceLink, feedback, responseID))
        mysql.connection.commit()
        return redirect(url_for('feedback'))



#delete data from database
@app.route('/delete3/<string:id_data>', methods = ['GET'])
def delete3(id_data):
    flash("Record Has Been Deleted Successfully")
    cur = mysql.connection.cursor()
    cur.execute("DELETE FROM reference WHERE referenceID=%s", (id_data,))
    mysql.connection.commit()
    return redirect(url_for('feedback'))

#edit data from database
@app.route('/update3',methods=['POST','GET'])
def update3():

    if request.method == 'POST':
        id_data = request.form['referenceID']
        referenceLink = request.form['referenceLink']
        feedback = request.form['feedback']
        responseID = request.form['responseID']
        cur = mysql.connection.cursor()
        cur.execute("""
               UPDATE reference
               SET referenceLink=%s, feedback=%s, responseID=%s
               WHERE referenceID=%s
            """, (referenceLink, feedback, responseID, id_data))
        flash("Data Updated Successfully")
        mysql.connection.commit()
        return redirect(url_for('feedback'))
#end of reference table cms

#runs the programs
if __name__ == "__main__":
    app.run(debug=True)